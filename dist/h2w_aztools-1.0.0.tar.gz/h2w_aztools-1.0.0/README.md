# Aztools 

Python Library for Interacting with Azure API's 